import { Request, Response } from 'express';
import { createAd as createAdService, getAds as getAdsService, getAdById as getAdByIdService } from '../services/ad.service';
import { AuthRequest } from '../middleware/auth.middleware';

export const getAds = async (req: Request, res: Response) => {
    try {
        const ads = await getAdsService();
        res.json(ads);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка получения объявлений', error });
    }
};

export const getAdById = async (req: Request, res: Response) => {
    try {
        const ad = await getAdByIdService(Number(req.params.id));
        if (!ad) {
            return res.status(404).json({ message: 'Объявление не найдено' });
        }
        res.json(ad);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка получения объявления', error });
    }
};

export const createAd = async (req: AuthRequest, res: Response) => {
    try {
        const { title, description, price, images } = req.body;
        
        if (!title || !description || !price) {
            return res.status(400).json({ message: 'Не все обязательные поля заполнены' });
        }
        
        if (!req.user || !req.user.userId) {
            return res.status(401).json({ message: 'Не авторизован' });
        }
        
        const ad = await createAdService({
            title,
            description,
            price,
            userId: req.user.userId
        });
        
        res.status(201).json(ad);
    } catch (error) {
        res.status(500).json({ message: 'Ошибка создания объявления', error });
    }
};