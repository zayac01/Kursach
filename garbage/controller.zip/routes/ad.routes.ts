import express from 'express';
import { getAds, getAdById, createAd } from '../controller/ad.controller';

const router = express.Router();

// Получение всех объявлений
router.get('/', getAds);

// Получение объявления по ID
router.get('/:id', getAdById);

// Создание нового объявления
router.post('/', createAd);

export default router;