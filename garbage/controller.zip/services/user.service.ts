import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient();

export const registerUser = async ({ username, email, password }: { username: string, email: string, password: string }) => {
  return await prisma.user.create({
    data: {
      username,
      email,
      password
    }
  });
};

export const findUserByEmail = async (email: string) => {
  return await prisma.user.findUnique({
    where: { email }
  });
};