import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

export const getAds = async () => {
    return await prisma.ad.findMany({
        include: {
            user: true,
            images: true
        }
    });
};

export const getAdById = async (id: number) => {
    return await prisma.ad.findUnique({
        where: { id },
        include: {
            user: true,
            images: true
        }
    });
};

export const createAd = async ({ title, description, price, userId }: { title: string, description: string, price: number, userId: number }) => {
    const ad = await prisma.ad.create({
        data: {
            title,
            description,
            price,
            userId
        }
    });
    
    return ad;
};